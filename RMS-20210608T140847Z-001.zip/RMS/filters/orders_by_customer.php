<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM customer";
$query = mysqli_query($conn, $sql);
$items = mysqli_fetch_all($query, MYSQLI_ASSOC);


if ($_GET['c_id']) {
    $sql = "SELECT * FROM orders
        inner join menu on menu.m_id=orders.m_id
        inner join waiter on waiter.w_id=orders.w_id
        inner join customer on customer.c_id=orders.c_id
        where orders.c_id=" . $_GET['c_id'];
    $query = mysqli_query($conn, $sql);
    $orders = mysqli_fetch_all($query, MYSQLI_ASSOC);
} else {
    $orders = [];
}


?>

<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>

<body>
<div>
    <div class="row" style="height: 100%;">
        <?php
        include '../sidebar.php';
        ?>
        <div class="col-md-10">



            <h1 class="text-center">Orders by Customers</h1>
            <form method="get" action="orders_by_customer.php" class="mt-5">
                <div class="form-group">
                    <label for="id">Select customer: </label>
                    <select name="c_id">
                        <?php foreach ($items as $item) {?>
                        <option value="<?php echo $item['c_id']?>"><?php echo $item['c_name']?></option>
                        <?php } ?>
                    </select>

                    <button type="submit" class="btn btn-primary ml-4">Search</button>
                </div>


            </form>

            <h5 class="text-right">Total orders: <?php echo sizeof($orders) ?></h5>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Date</th>
                    <th scope="col">Menu Item</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Waiter</th>
                    <th scope="col">Customer</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $user) { ?>
                    <tr>
                        <th scope="row"><?php echo $user['o_id'] ?></th>
                        <td><?php echo $user['o_date'] ?></td>
                        <td><?php echo $user['m_name'] ?></td>
                        <td><?php echo $user['o_quantity'] ?></td>
                        <td><?php echo ($user['o_quantity'] * $user['m_price']) ?></td>
                        <td><?php echo $user['w_name'] ?></td>
                        <td><?php echo $user['c_name'] ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
