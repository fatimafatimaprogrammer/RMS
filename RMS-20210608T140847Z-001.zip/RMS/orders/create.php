<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM customer";
$query = mysqli_query($conn, $sql);
$customer = mysqli_fetch_all($query, MYSQLI_ASSOC);

$sql = "SELECT * FROM menu";
$query = mysqli_query($conn, $sql);
$items = mysqli_fetch_all($query, MYSQLI_ASSOC);

$sql = "SELECT * FROM waiter";
$query = mysqli_query($conn, $sql);
$waiters = mysqli_fetch_all($query, MYSQLI_ASSOC);

$sql = "SELECT * FROM user";
$query = mysqli_query($conn, $sql);
$users = mysqli_fetch_all($query, MYSQLI_ASSOC);

$sql = "SELECT * FROM chef";
$query = mysqli_query($conn, $sql);
$chefs = mysqli_fetch_all($query, MYSQLI_ASSOC);


?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <h1 class="text-center">Create Order</h1>
    <form method="get" action="create_form.php">

        <div class="form-group">
            <label for="date">Date</label>
            <input type="date" class="form-control" id="date" name="date">
        </div>

        <label for="name">Menu</label>
        <select class="form-control" name="m_id">
            <?php foreach ($items as $item) { ?>
                <option value="<?php echo $item['m_id'] ?>"><?php echo $item['m_name'] ?></option>
            <?php } ?>
        </select>

        <div class="form-group">
            <label for="quantity">Quantity</label>
            <input type="number" class="form-control" id="quantity" name="quantity">
        </div>

        <label for="name">Waiter</label>
        <select class="form-control" name="w_id">
            <?php foreach ($waiters as $item) { ?>
                <option value="<?php echo $item['w_id'] ?>"><?php echo $item['w_name'] ?></option>
            <?php } ?>
        </select>

        <label for="name">Customer</label>
        <select class="form-control" name="c_id">
            <?php foreach ($customer as $item) { ?>
                <option value="<?php echo $item['c_id'] ?>"><?php echo $item['c_name'] ?></option>
            <?php } ?>
        </select>

        <label for="name">Users</label>
        <select class="form-control" name="u_id">
            <?php foreach ($users as $item) { ?>
                <option value="<?php echo $item['u_id'] ?>"><?php echo $item['u_name'] ?></option>
            <?php } ?>
        </select>

        <label for="name">Chef</label>
        <select class="form-control" name="chef_id">
            <?php foreach ($chefs as $item) { ?>
                <option value="<?php echo $item['chef_id'] ?>"><?php echo $item['chef_name'] ?></option>
            <?php } ?>
        </select>

     <label for="name">Status</label>-->
       <select class="form-control" name="c_id">-->
               <option value="void">Pending</option>-->
                <option value="void">Void</option>-->
                <option value="served">Served</option>-->
        </select>-->
  <!-- 
        <br>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
