<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "INSERT INTO orders (o_date, o_status, o_quantity, w_id, c_id, m_id, u_id, chef_id) 
VALUES 
('".$_GET['date']."', "served", ".$_GET['quantity'].", ".$_GET['w_id'].", ".$_GET['c_id'].", ".$_GET['m_id'].", ".$_GET['u_id'].", ".$_GET['chef_id'].")";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record created successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error creating record: " . $conn->error;
}

?>
