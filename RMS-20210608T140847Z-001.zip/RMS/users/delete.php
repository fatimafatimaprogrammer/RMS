<?php
include '../db_connection.php';
$conn = OpenCon();

//echo $_GET['id'];
$sql = "DELETE FROM user WHERE u_id=" . $_GET['id'];
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

header("Location: list.php");
die();
?>
