<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "INSERT INTO user (u_id, u_name, u_email, u_password) VALUES ('".$_GET['id']."','".$_GET['name']."', '".$_GET['email']."', '".$_GET['password']."')";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record created successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error creating record: " . $conn->error;
}

?>
