<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "UPDATE user SET u_name='" . $_GET['name'] . "', u_email='" . $_GET['email'] . "', u_password='" . $_GET['password'] . "' WHERE u_id=" . $_GET['id'];
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error updating record: " . $conn->error;
}

?>
