INSERT INTO waiter(w_id,w_name,w_salary,w_hiredate) VALUES
 (1,'qw',1233,'2020/1/2')
,(2,'qq',122,'2021/2/3')
,(3,'as',3211,'2020/3/3')
,(4,'rrr',23342,'2020/4/4');

INSERT INTO customer(c_id,c_name,c_phonenumber,c_address) VALUES
 (1,'fatima',3399293,'islamabad')
,(2,'kaynat',2563789,'islamabad')
,(3,'zainab',6677123,'multan')
,(4,'maryam',3738333,'lahore');

INSERT INTO menu(m_id,m_items,m_price) VALUES
 (1,'pizza',2000)
,(2,'burger',800)
,(3,'fries',180)
,(4,'pasta',920);


INSERT INTO chef(chef_id,chef_name,chef_salary,chef_hiredate) VALUES
 (1,'xyz',5000,'2021/1/1')
,(2,'abc',10000,'2021/2/1')
,(3,'lmn',15000,'2021/9/9')
,(4,'opq',1222,'2020/5/4');

INSERT INTO user(u_id,u_name,u_password,u_email) VALUES
 (10,'mack',1234,'mack@gmail.com')
,(11,'john',4567,'john@gmail.com')
,(12,'smith',8910,'smith@gmail.com')
,(13,'clark',1122,'clark@gmail.com');

INSERT INTO orders(o_id,o_date,o_status,o_quantity,c_id,m_id,w_id,u_id,chef_id) VALUES
 (1,'2020/1/2','served',5,1,1,2,10,2)
,(2,'2020/1/1','served',3,2,1,2,10,3)
,(3,'2021/3/3','served',2,3,3,3,11,1)
,(4,'2021/2/3','served',4,4,2,1,13,1);


