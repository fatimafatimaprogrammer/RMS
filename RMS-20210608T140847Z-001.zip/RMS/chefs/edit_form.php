<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "UPDATE chef SET chef_name='" . $_GET['name'] . "', chef_salary='" . $_GET['salary'] . "', chef_hiredate='" . $_GET['hiredate'] . "' WHERE chef_id=" . $_GET['id'];
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error updating record: " . $conn->error;
}

?>
