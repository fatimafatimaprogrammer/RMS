<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "INSERT INTO chef (chef_id, chef_name, chef_salary, chef_hiredate) VALUES ('".$_GET['id']."','" . $_GET['name'] . "', '" . $_GET['salary'] . "', '" . $_GET['hiredate'] . "')";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record created successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error creating record: " . $conn->error;
}

?>
