<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM chef WHERE chef_id = ". $_GET['id'];
$query = mysqli_query($conn, $sql);
$user = mysqli_fetch_all($query, MYSQLI_ASSOC)[0];
?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="container">
<h1 class="text-center">Edit Chef</h1>
<form method="get" action="edit_form.php">
    <div class="form-group d-none">
        <label for="id">ID</label>
        <input type="number" class="form-control" id="id" name="id" value="<?php echo $user['chef_id'] ?>">
    </div>
    <div class="form-group">
        <label for="id">ID</label>
        <input type="number" class="form-control" id="id" value="<?php echo $user['chef_id'] ?>" disabled>
    </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['chef_name'] ?>">
    </div>
    <div class="form-group">
        <label for="salary">Salary</label>
        <input type="text" class="form-control" id="salary" name="salary" value="<?php echo $user['chef_salary'] ?>">
    </div>
    <div class="form-group">
        <label for="hiredate">Hire Date</label>
        <input type="date" class="form-control" id="hiredate" name="hiredate" value="<?php echo $user['chef_hiredate'] ?>">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
