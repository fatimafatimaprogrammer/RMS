<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "UPDATE waiter SET w_name='" . $_GET['name'] . "', w_salary='" . $_GET['salary'] . "', w_hiredate='" . $_GET['hiredate'] . "' WHERE w_id=" . $_GET['id'];
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error updating record: " . $conn->error;
}

?>
