<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM menu";
$query = mysqli_query($conn, $sql);
$users = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>

<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>

<body>
<div>
    <div class="row" style="height: 100%;">
        <?php
        include '../sidebar.php';
        ?>
        <div class="col-md-10">
            <h1 class="text-center">All Menu Items</h1>

            <a href="create.php">
                <button>Create Item</button>
            </a>
            <h5 class="text-right">Total items: <?php echo sizeof($users) ?></h5>

            <table class="table">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $user) { ?>
                    <tr>
                        <th scope="row"><?php echo $user['m_id'] ?></th>
                        <td><?php echo $user['m_name'] ?></td>
                        <td><?php echo $user['m_price'] ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $user['m_id'] ?>">Edit</a>
                            <a href="delete.php?id=<?php echo $user['m_id'] ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
