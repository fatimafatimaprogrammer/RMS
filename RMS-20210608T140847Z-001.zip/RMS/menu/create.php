<?php
//include '../db_connection.php';
//$conn = OpenCon();
//
//$sql = "SELECT * FROM user";
//$query = mysqli_query($conn, $sql);
//$users = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="container">
<h1 class="text-center">Create Item</h1>
<form method="get" action="create_form.php">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name">
    </div>
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" class="form-control" id="price" name="price">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
