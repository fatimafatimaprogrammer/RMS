<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "SELECT * FROM menu WHERE m_id = ". $_GET['id'];
$query = mysqli_query($conn, $sql);
$user = mysqli_fetch_all($query, MYSQLI_ASSOC)[0];
?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<div class="container">
<h1 class="text-center">Edit Item</h1>
<form method="get" action="edit_form.php">
    <div class="form-group d-none">
        <label for="id">ID</label>
        <input type="number" class="form-control" id="id" name="id" value="<?php echo $user['m_id'] ?>">
    </div>
    <div class="form-group">
        <label for="id">ID</label>
        <input type="number" class="form-control" id="id" value="<?php echo $user['m_id'] ?>" disabled>
    </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['m_name'] ?>">
    </div>
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" class="form-control" id="price" name="price" value="<?php echo $user['m_price'] ?>">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
