<?php
include '../db_connection.php';
$conn = OpenCon();

//echo $_GET['id'];
$sql = "DELETE FROM menu WHERE m_id=" . $_GET['id'];
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error deleting record: " . $conn->error;
}


?>
