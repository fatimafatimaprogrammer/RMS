<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "INSERT INTO menu (m_name, m_price) VALUES ('" . $_GET['name'] . "', '" . $_GET['price'] . "')";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record created successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error creating record: " . $conn->error;
}

?>
