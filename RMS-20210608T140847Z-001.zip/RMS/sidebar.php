<?php
$root = 'http://localhost/';
?>

<div class="col-md-2 pr-0" style="background-color: #384558; color: #fff">
    <h2 class="text-center">RMS</h2>
    <div style="padding-top: 50px">
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
               href="<?php echo $root ?>menu/list.php">Menu</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
               href="<?php echo $root ?>customers/list.php">Customer</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
            href="<?php echo $root ?>users/list.php">Users</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
            href="<?php echo $root ?>waiter/list.php">Waiter</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
            href="<?php echo $root ?>chefs/list.php">Chefs</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
            href="<?php echo $root ?>orders/list.php">Orders</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
            href="<?php echo $root ?>filters/orders_by_menu.php">Orders by menu</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
               href="<?php echo $root ?>filters/orders_by_customer.php">Orders by customer</a>
        </div>
        <div style="cursor: pointer; border: 1px solid #fff">
            <a style="padding-left: 20px; color: #fff;"
               href="<?php echo $root ?>filters/orders_by_waiter.php">Orders by waiter</a>
        </div>
    </div>
</div>
