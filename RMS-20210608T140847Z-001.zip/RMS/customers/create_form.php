<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "INSERT INTO customer (c_id, c_name, c_address, c_phonenumber) VALUES ('".$_GET['id']."','".$_GET['name']."', '".$_GET['address']."', ".$_GET['phone'].")";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record created successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error creating record: " . $conn->error;
}

?>
