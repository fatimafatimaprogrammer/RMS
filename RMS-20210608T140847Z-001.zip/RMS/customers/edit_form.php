<?php
include '../db_connection.php';
$conn = OpenCon();

$sql = "UPDATE customer SET c_name='" . $_GET['name'] . "', c_address='" . $_GET['address'] . "', c_phonenumber='" . $_GET['phone'] . "' WHERE c_id=" . $_GET['id'];
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header("Location: list.php");
    die();
} else {
    echo "Error updating record: " . $conn->error;
}

?>
